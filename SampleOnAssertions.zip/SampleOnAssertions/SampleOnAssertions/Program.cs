﻿namespace SampleOnAssertions
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
        public bool Odd_or_Even(int x)
        {
            if(x%2==1)
            {
                Console.WriteLine($"The Given Number {x} is odd Number");
                return true;
            }
            else
            {
                Console.WriteLine($"The Given Number {x} is Even Number");
                return true;
            }
        }

        public bool Lessthan(int x,int y)
        {
            if(x>y) 
            {
                Console.WriteLine($"The integer x {x} is greater than integer y {y} ");
                return true;
            
            }
            else
                Console.WriteLine($"The integer x {x} is lessthan than integer y {y} ");
                return false;
        }

        public Program SameClassObject()
        {
            return this;
        } 

        public string MakeNull(string s)
        {
            s = null;
            return s;
        }

        public string NullToValue(string s=null)
        {
            s = "Not Null Now";
            return s;
        }
        public int PrimeNumber(int x)
        {
            for(int j = 2; j < x;j++)
            {
                if (x % j == 0)
                {
                    return 0;
                }
            }
            return 1;
        }
    }

    public class SampleAssertion
    {
        public Program OtherClassObject()
        {
            Program p=new Program();
            return p;
        }
        public int Square(int x)
        {
            return x*x;
        }

        public SampleAssertion Instance()
        {
            return this;
        }
    }
}