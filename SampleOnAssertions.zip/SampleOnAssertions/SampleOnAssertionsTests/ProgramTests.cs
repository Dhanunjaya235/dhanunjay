﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace SampleOnAssertions.Tests
{
    [TestClass]
    public class ProgramTests
    {
        Program p = new Program();
        SampleAssertion s = new SampleAssertion();
        [TestMethod]
        public void Odd_or_EvenTest()
        {
            bool result = p.Odd_or_Even(11);
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void SameClassObjectTest()
        {
            Object pro = p.SameClassObject();
            Assert.AreSame(p, pro);

        }
        [TestMethod]
        public void OtherClassObjectTest()
        {
            Object sa = s.OtherClassObject();
            Assert.AreNotSame(s, sa);
        }
        [TestMethod]

        public void SquareTest()
        {
            int number = 20;
            int result = s.Square(number);
            if (result != 400)
            {
                Assert.Fail();
            }
        }
        [TestMethod]

        public void InstanceTest()
        {
            Object sa = s.Instance();
            Assert.IsInstanceOfType(sa, typeof(SampleAssertion));
            Assert.IsNotInstanceOfType(sa, typeof(Program));
        }
        [TestMethod]

        public void MakeNullTest()
        {
            string name = "Method";
            string str = p.MakeNull(name);
            Assert.IsNull(str);
        }
        [TestMethod]

        public void NullToValueTest()
        {
            string s = null;
            string str = p.NullToValue(s);
            Assert.IsNotNull(str);
        }

        [TestMethod]

        public void LessthanTest()
        {
            int number1 = 20;
            int number2 = 20;
            bool result = p.Lessthan(number1, number2);
            Assert.IsFalse(result);
        }

        [TestMethod]

        public void PrimeNumberTest()
        {
            int number1 = 20;
            int result = p.PrimeNumber(number1);
            Assert.AreEqual(0, result);
            Assert.AreNotEqual(1, result);

            int number2 = 13;
            int result2 = p.PrimeNumber(number2);
            Assert.AreEqual(1, result2);
            Assert.AreNotEqual(0, result2);
        }
    }
}